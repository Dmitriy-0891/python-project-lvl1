#!:/usr/bin/env python3

import prompt
import random

def main():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print('Hello, ' + name + '!')
    print('What number is missing in the progression?')
    x = 1
    while x <= 4:
        if x == 4:
            print("Congratulations, " + name + "!")
        else:
            first_number = random_randint(1,1000000)
            step = random_randint(1,1000)
            last_number = first_number + step * 10
            progression = list(range(first_number, last_number, step)
            # i - this is the ordinal number of a number in the sequence
            i = random.randint(0,9)
            # х - this is the value by which the random number in the sequence will be replaced
            x = ".."
            right_answer = progression[i]
            del progression[i]
            progression.insert(i, x)
            print("Question: " + str(progression[0]) + " " str(progression[1]) + " " + str(progression[2]) + " " + str(progression[3]) + " " + str(progression[4]) + " " + str(progression[5]) + " " + str(progression[6]) + " " + str(progression[7]) + " " + str(progression[8]) + " " + str(progression[9]))
            answer = prompt.string('Your answer: ')
            if answer == str(right_answer):
                print("Correct!")
            else:
                print( "'" + answer + "' is wrong answer:(. Correct answer is " + str(right_answer) + ".\nLet`s try again " + name + "!")
                break
        x += 1

if __name__ == '__main__':
    main()