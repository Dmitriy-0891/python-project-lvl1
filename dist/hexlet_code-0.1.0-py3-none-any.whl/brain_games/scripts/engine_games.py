#!:usr/bin/env python3

def main(game_script):
    x = 1
    while x <= 4:
        if x == 4:
            print("Congratulations, " + name + "!")
        else:
            game_script

        x += 1


if __name__ == '__main__':
    main()

